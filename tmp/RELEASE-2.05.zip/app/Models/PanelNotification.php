<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\DatabaseNotification;
class PanelNotification extends DatabaseNotification
{
    use HasFactory;

    protected $table = 'panel_notifications';
}
